import { Link, useLocation } from "wouter";
import { Users, LayoutDashboard, Briefcase, Plus, Menu } from "lucide-react";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem, 
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-slate-50/50">
        <Sidebar className="border-r border-slate-200">
          <SidebarHeader className="h-16 flex items-center px-4 pt-4 border-b border-sidebar-border/50">
            <div className="flex items-center gap-2 font-bold text-lg text-sidebar-foreground">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground shadow-sm">
                <Briefcase size={18} />
              </div>
              <span className="tracking-tight">StaffBase</span>
            </div>
          </SidebarHeader>
          <SidebarContent className="px-3 py-4">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  asChild 
                  isActive={location === "/"}
                  className="font-medium h-10"
                >
                  <Link href="/" className="flex items-center gap-3">
                    <LayoutDashboard size={18} />
                    <span>Dashboard</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  asChild 
                  isActive={location.startsWith("/employees")}
                  className="font-medium h-10"
                >
                  <Link href="/employees" className="flex items-center gap-3">
                    <Users size={18} />
                    <span>Employees</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>
        
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-16 flex items-center justify-between px-6 bg-white border-b border-slate-200 sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="-ml-2 md:hidden" />
              <div className="hidden sm:block">
                <h2 className="text-sm font-semibold text-slate-800">
                  {location === "/" ? "Overview" : location.startsWith("/employees") ? "Directory" : "StaffBase"}
                </h2>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/employees/new" className="hidden sm:flex inline-flex h-9 items-center justify-center whitespace-nowrap rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90">
                <Plus size={16} className="mr-2" />
                Add Employee
              </Link>
              <div className="w-8 h-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-600 font-bold text-xs">
                HR
              </div>
            </div>
          </header>
          <main className="flex-1 p-6 md:p-8 overflow-y-auto">
            <div className="mx-auto max-w-6xl w-full">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}