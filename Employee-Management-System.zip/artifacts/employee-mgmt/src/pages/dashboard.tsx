import { Users, UserCheck, UserMinus, Building2, TrendingUp, UserPlus, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useGetStatsSummary, useGetStatsByDepartment, useGetRecentHires } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function Dashboard() {
  const { data: summary, isLoading: isLoadingSummary } = useGetStatsSummary();
  const { data: deptStats, isLoading: isLoadingDept } = useGetStatsByDepartment();
  const { data: recentHires, isLoading: isLoadingRecent } = useGetRecentHires();

  const formatCurrency = (val: number | null | undefined) => {
    if (val === null || val === undefined) return "$0";
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Overview of your workforce metrics.</p>
        </div>
        <Button asChild>
          <Link href="/employees/new">
            <UserPlus className="mr-2 h-4 w-4" />
            Add Employee
          </Link>
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Total Employees</CardTitle>
            <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-md flex items-center justify-center">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-3xl font-bold text-slate-900">{summary?.totalEmployees || 0}</div>
            )}
          </CardContent>
        </Card>
        
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Active Rate</CardTitle>
            <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-md flex items-center justify-center">
              <UserCheck className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-3xl font-bold text-slate-900">
                {summary?.totalEmployees ? Math.round((summary.activeEmployees / summary.totalEmployees) * 100) : 0}%
              </div>
            )}
            <p className="text-xs text-slate-500 mt-1">{summary?.activeEmployees || 0} active employees</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Departments</CardTitle>
            <div className="w-8 h-8 bg-purple-50 text-purple-600 rounded-md flex items-center justify-center">
              <Building2 className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-3xl font-bold text-slate-900">{summary?.departments || 0}</div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Avg. Salary</CardTitle>
            <div className="w-8 h-8 bg-amber-50 text-amber-600 rounded-md flex items-center justify-center">
              <TrendingUp className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-3xl font-bold text-slate-900">{formatCurrency(summary?.avgSalary)}</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        {/* Chart */}
        <Card className="md:col-span-4 shadow-sm border-slate-200">
          <CardHeader>
            <CardTitle>Headcount by Department</CardTitle>
            <CardDescription>Current active and inactive distribution</CardDescription>
          </CardHeader>
          <CardContent className="pl-0">
            {isLoadingDept ? (
              <div className="h-[300px] flex items-center justify-center">
                <Skeleton className="h-[250px] w-full mx-6" />
              </div>
            ) : (
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={deptStats || []} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="department" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 12 }}
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 12 }}
                    />
                    <Tooltip 
                      cursor={{ fill: '#f8fafc' }}
                      contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {(deptStats || []).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill="hsl(var(--primary))" />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Hires */}
        <Card className="md:col-span-3 shadow-sm border-slate-200 flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle>Recent Hires</CardTitle>
              <CardDescription>
                {summary?.newHiresThisMonth || 0} joined this month
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild className="text-primary hover:text-primary/80">
              <Link href="/employees">
                View all
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="flex-1">
            {isLoadingRecent ? (
              <div className="space-y-4 mt-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                ))}
              </div>
            ) : recentHires && recentHires.length > 0 ? (
              <div className="space-y-5 mt-4">
                {recentHires.slice(0, 5).map(employee => (
                  <Link key={employee.id} href={`/employees/${employee.id}`}>
                    <div className="flex items-center justify-between group cursor-pointer hover:bg-slate-50 p-2 -mx-2 rounded-md transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-medium text-sm border border-slate-200">
                          {employee.firstName[0]}{employee.lastName[0]}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900 group-hover:text-primary transition-colors">
                            {employee.firstName} {employee.lastName}
                          </p>
                          <p className="text-xs text-slate-500">{employee.position} • {employee.department}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="font-normal text-xs bg-white text-slate-600">
                          {new Date(employee.hireDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                        </Badge>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 space-y-3 py-8">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center">
                  <UserMinus className="h-6 w-6 text-slate-400" />
                </div>
                <p className="text-sm">No recent hires to display</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}