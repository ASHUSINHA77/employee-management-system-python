import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ArrowLeft, Edit2, Trash2, Mail, Phone, MapPin, Building, Briefcase, Calendar, Info } from "lucide-react";
import { 
  useGetEmployee, 
  useUpdateEmployee, 
  useDeleteEmployee,
  useListDepartments,
  EmployeeUpdate
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const employeeSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional().nullable(),
  department: z.string().min(1, "Department is required"),
  position: z.string().min(2, "Position must be at least 2 characters"),
  salary: z.coerce.number().min(0, "Salary must be a positive number").optional().nullable(),
  hireDate: z.string().min(1, "Hire date is required"),
  status: z.enum(["active", "inactive"]),
  address: z.string().optional().nullable(),
});

type EmployeeFormValues = z.infer<typeof employeeSchema>;

export default function EmployeeDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0", 10);
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const [isEditModalOpen, setIsEditModalOpen] = useState(searchParams.get("edit") === "true");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: employee, isLoading, isError } = useGetEmployee(id, { 
    query: { enabled: !!id, queryKey: ["/api/employees", id.toString()] } 
  });
  
  const { data: departments } = useListDepartments();
  const updateEmployee = useUpdateEmployee();
  const deleteEmployee = useDeleteEmployee();

  const form = useForm<EmployeeFormValues>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      department: "",
      position: "",
      salary: undefined,
      hireDate: "",
      status: "active",
      address: "",
    },
  });

  // Sync form when employee loads
  const initializedForId = useRef<number | null>(null);
  useEffect(() => {
    if (employee && initializedForId.current !== id) {
      initializedForId.current = id;
      form.reset({
        firstName: employee.firstName,
        lastName: employee.lastName,
        email: employee.email,
        phone: employee.phone || "",
        department: employee.department,
        position: employee.position,
        salary: employee.salary || undefined,
        hireDate: employee.hireDate,
        status: employee.status,
        address: employee.address || "",
      });
    }
  }, [employee, id, form]);

  const onEditSubmit = (data: EmployeeFormValues) => {
    const payload: EmployeeUpdate = {
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      phone: data.phone || undefined,
      department: data.department,
      position: data.position,
      salary: data.salary || undefined,
      hireDate: data.hireDate,
      status: data.status,
      address: data.address || undefined,
    };

    updateEmployee.mutate(
      { id, data: payload },
      {
        onSuccess: (updatedData) => {
          queryClient.setQueryData(["/api/employees", id.toString()], updatedData);
          queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats/summary"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats/by-department"] });
          
          setIsEditModalOpen(false);
          // Remove ?edit=true if present
          if (searchParams.get("edit")) {
            setLocation(`/employees/${id}`);
          }
          
          toast({
            title: "Employee Updated",
            description: "The employee record has been successfully updated.",
          });
        },
        onError: (error: any) => {
          toast({
            title: "Update Failed",
            description: error?.response?.data?.error || "An error occurred while updating.",
            variant: "destructive",
          });
        }
      }
    );
  };

  const handleDelete = () => {
    deleteEmployee.mutate(
      { id },
      {
        onSuccess: () => {
          toast({
            title: "Employee Deleted",
            description: "The employee record has been removed.",
          });
          queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats/summary"] });
          queryClient.invalidateQueries({ queryKey: ["/api/stats/by-department"] });
          setLocation("/employees");
        },
        onError: (error: any) => {
          toast({
            title: "Delete Failed",
            description: error?.response?.data?.error || "An error occurred while deleting.",
            variant: "destructive",
          });
          setIsDeleteDialogOpen(false);
        }
      }
    );
  };

  if (isError || (!isLoading && !employee)) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Info className="h-12 w-12 text-slate-400 mb-4" />
        <h2 className="text-xl font-semibold text-slate-900">Employee Not Found</h2>
        <p className="text-slate-500 mt-2 mb-6">The employee record you're looking for doesn't exist or has been deleted.</p>
        <Button asChild>
          <Link href="/employees">Return to Directory</Link>
        </Button>
      </div>
    );
  }

  const formatCurrency = (val: number | null | undefined) => {
    if (val === null || val === undefined) return "Not specified";
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(val);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild className="h-8 w-8 text-slate-500">
            <Link href="/employees">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            {isLoading ? (
              <Skeleton className="h-8 w-64 mb-1" />
            ) : (
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                {employee?.firstName} {employee?.lastName}
              </h1>
            )}
            {isLoading ? (
              <Skeleton className="h-4 w-32" />
            ) : (
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <span>ID: EMP-{employee?.id.toString().padStart(4, '0')}</span>
                <span>•</span>
                <Badge variant={employee?.status === "active" ? "default" : "secondary"} className={
                  employee?.status === "active" 
                    ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border-none font-medium h-5" 
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200 border-none font-medium h-5"
                }>
                  {employee?.status.charAt(0).toUpperCase()}{employee?.status.slice(1)}
                </Badge>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsEditModalOpen(true)} disabled={isLoading} className="border-slate-200 bg-white">
            <Edit2 className="h-4 w-4 mr-2" />
            Edit Profile
          </Button>
          <Button variant="outline" className="text-destructive border-slate-200 hover:bg-destructive/5" onClick={() => setIsDeleteDialogOpen(true)} disabled={isLoading}>
            <Trash2 className="h-4 w-4" />
            <span className="sr-only sm:not-sr-only sm:ml-2">Delete</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Profile Card */}
        <div className="md:col-span-1 space-y-6">
          <Card className="shadow-sm border-slate-200 overflow-hidden">
            <div className="h-24 bg-gradient-to-r from-primary/10 to-primary/5"></div>
            <CardContent className="pt-0 relative px-6 pb-6">
              <div className="absolute -top-12 left-6 h-24 w-24 rounded-xl bg-white p-1 shadow-sm border border-slate-200">
                <div className="h-full w-full rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-3xl">
                  {isLoading ? <Skeleton className="h-full w-full rounded-lg" /> : `${employee?.firstName[0]}${employee?.lastName[0]}`}
                </div>
              </div>
              
              <div className="mt-14 space-y-1">
                {isLoading ? (
                  <>
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </>
                ) : (
                  <>
                    <h2 className="text-xl font-bold text-slate-900">{employee?.firstName} {employee?.lastName}</h2>
                    <p className="text-slate-600 font-medium">{employee?.position}</p>
                    <p className="text-slate-500 text-sm">{employee?.department} Department</p>
                  </>
                )}
              </div>
              
              <Separator className="my-6 bg-slate-100" />
              
              <div className="space-y-4">
                <div className="flex gap-3 text-sm">
                  <Mail className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                  <div className="overflow-hidden">
                    <p className="text-slate-500 font-medium text-xs uppercase tracking-wider mb-0.5">Email</p>
                    {isLoading ? <Skeleton className="h-4 w-full" /> : <p className="text-slate-900 truncate" title={employee?.email}>{employee?.email}</p>}
                  </div>
                </div>
                
                <div className="flex gap-3 text-sm">
                  <Phone className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-slate-500 font-medium text-xs uppercase tracking-wider mb-0.5">Phone</p>
                    {isLoading ? <Skeleton className="h-4 w-24" /> : <p className="text-slate-900">{employee?.phone || "Not provided"}</p>}
                  </div>
                </div>
                
                <div className="flex gap-3 text-sm">
                  <MapPin className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-slate-500 font-medium text-xs uppercase tracking-wider mb-0.5">Location</p>
                    {isLoading ? <Skeleton className="h-4 w-32" /> : <p className="text-slate-900">{employee?.address || "Not provided"}</p>}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Employment Details */}
        <div className="md:col-span-2 space-y-6">
          <Card className="shadow-sm border-slate-200 h-full">
            <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
              <CardTitle className="text-lg flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-slate-400" />
                Employment Information
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-8 gap-x-6">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Building className="h-4 w-4 text-slate-400" />
                    <h3 className="text-sm font-medium text-slate-500">Department</h3>
                  </div>
                  {isLoading ? <Skeleton className="h-6 w-32 mt-1" /> : <p className="text-base font-semibold text-slate-900">{employee?.department}</p>}
                </div>
                
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Briefcase className="h-4 w-4 text-slate-400" />
                    <h3 className="text-sm font-medium text-slate-500">Job Title</h3>
                  </div>
                  {isLoading ? <Skeleton className="h-6 w-40 mt-1" /> : <p className="text-base font-semibold text-slate-900">{employee?.position}</p>}
                </div>
                
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Calendar className="h-4 w-4 text-slate-400" />
                    <h3 className="text-sm font-medium text-slate-500">Hire Date</h3>
                  </div>
                  {isLoading ? <Skeleton className="h-6 w-32 mt-1" /> : <p className="text-base font-semibold text-slate-900">{formatDate(employee?.hireDate || "")}</p>}
                </div>
                
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-serif italic text-slate-400 h-4 w-4 flex items-center justify-center">$</span>
                    <h3 className="text-sm font-medium text-slate-500">Annual Compensation</h3>
                  </div>
                  {isLoading ? <Skeleton className="h-6 w-24 mt-1" /> : <p className="text-base font-semibold text-slate-900">{formatCurrency(employee?.salary)}</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Employee Profile</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onEditSubmit)} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl><Input type="email" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl><Input type="tel" {...field} value={field.value || ""} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Home Address</FormLabel>
                    <FormControl><Input {...field} value={field.value || ""} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="department"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a department" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {departments?.map(d => (
                            <SelectItem key={d.name} value={d.name}>{d.name}</SelectItem>
                          ))}
                          {!departments?.length && (
                            <>
                              <SelectItem value="Engineering">Engineering</SelectItem>
                              <SelectItem value="Design">Design</SelectItem>
                              <SelectItem value="Marketing">Marketing</SelectItem>
                              <SelectItem value="Sales">Sales</SelectItem>
                              <SelectItem value="HR">HR</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="position"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Title</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="salary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Salary ($)</FormLabel>
                      <FormControl><Input type="number" {...field} value={field.value === null || field.value === undefined ? "" : field.value} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="hireDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hire Date</FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t mt-6">
                <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={updateEmployee.isPending}>
                  {updateEmployee.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Employee Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {employee?.firstName} {employee?.lastName}'s record? This action cannot be undone and will permanently remove all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={deleteEmployee.isPending}>
              {deleteEmployee.isPending ? "Deleting..." : "Delete Record"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}