import { Router } from "express";
import { db, employeesTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

// GET /departments
router.get("/departments", async (_req, res) => {
  const rows = await db
    .select({
      name: employeesTable.department,
      employeeCount: sql<number>`count(*)::int`,
    })
    .from(employeesTable)
    .groupBy(employeesTable.department)
    .orderBy(employeesTable.department);

  return res.json(rows);
});

export default router;
