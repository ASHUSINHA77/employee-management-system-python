import { Router } from "express";
import { db, employeesTable } from "@workspace/db";
import { eq, sql, desc } from "drizzle-orm";

const router = Router();

// GET /stats/summary
router.get("/stats/summary", async (_req, res) => {
  const [summary] = await db
    .select({
      totalEmployees: sql<number>`count(*)::int`,
      activeEmployees: sql<number>`count(*) filter (where status = 'active')::int`,
      inactiveEmployees: sql<number>`count(*) filter (where status = 'inactive')::int`,
      departments: sql<number>`count(distinct department)::int`,
      avgSalary: sql<number | null>`avg(salary::numeric)`,
      newHiresThisMonth: sql<number>`count(*) filter (where date_trunc('month', hire_date::date) = date_trunc('month', current_date))::int`,
    })
    .from(employeesTable);

  return res.json({
    totalEmployees: summary.totalEmployees,
    activeEmployees: summary.activeEmployees,
    inactiveEmployees: summary.inactiveEmployees,
    departments: summary.departments,
    avgSalary: summary.avgSalary ? parseFloat(String(summary.avgSalary)) : null,
    newHiresThisMonth: summary.newHiresThisMonth,
  });
});

// GET /stats/by-department
router.get("/stats/by-department", async (_req, res) => {
  const rows = await db
    .select({
      department: employeesTable.department,
      count: sql<number>`count(*)::int`,
      avgSalary: sql<number | null>`avg(salary::numeric)`,
    })
    .from(employeesTable)
    .groupBy(employeesTable.department)
    .orderBy(employeesTable.department);

  return res.json(
    rows.map((r) => ({
      department: r.department,
      count: r.count,
      avgSalary: r.avgSalary ? parseFloat(String(r.avgSalary)) : null,
    })),
  );
});

// GET /stats/recent-hires
router.get("/stats/recent-hires", async (_req, res) => {
  const employees = await db
    .select()
    .from(employeesTable)
    .orderBy(desc(employeesTable.hireDate))
    .limit(5);

  return res.json(
    employees.map((e) => ({
      ...e,
      salary: e.salary ? parseFloat(e.salary) : null,
    })),
  );
});

export default router;
