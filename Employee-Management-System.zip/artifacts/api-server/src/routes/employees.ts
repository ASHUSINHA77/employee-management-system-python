import { Router } from "express";
import { db, employeesTable } from "@workspace/db";
import { eq, ilike, and, or, sql, desc } from "drizzle-orm";
import {
  ListEmployeesQueryParams,
  CreateEmployeeBody,
  GetEmployeeParams,
  UpdateEmployeeParams,
  UpdateEmployeeBody,
  DeleteEmployeeParams,
} from "@workspace/api-zod";

const router = Router();

// GET /employees
router.get("/employees", async (req, res) => {
  const parsed = ListEmployeesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid query parameters" });
  }

  const { search, department, status } = parsed.data;

  const conditions = [];

  if (search) {
    conditions.push(
      or(
        ilike(employeesTable.firstName, `%${search}%`),
        ilike(employeesTable.lastName, `%${search}%`),
        ilike(employeesTable.email, `%${search}%`),
        ilike(employeesTable.position, `%${search}%`),
      ),
    );
  }

  if (department) {
    conditions.push(eq(employeesTable.department, department));
  }

  if (status) {
    conditions.push(eq(employeesTable.status, status as "active" | "inactive"));
  }

  const employees = await db
    .select()
    .from(employeesTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(employeesTable.createdAt));

  return res.json(
    employees.map((e) => ({
      ...e,
      salary: e.salary ? parseFloat(e.salary) : null,
    })),
  );
});

// POST /employees
router.post("/employees", async (req, res) => {
  const parsed = CreateEmployeeBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.message });
  }

  const { salary, hireDate, ...rest } = parsed.data;

  const [created] = await db
    .insert(employeesTable)
    .values({
      ...rest,
      hireDate: hireDate instanceof Date ? hireDate.toISOString().slice(0, 10) : String(hireDate),
      salary: salary !== undefined ? String(salary) : null,
    })
    .returning();

  return res.status(201).json({
    ...created,
    salary: created.salary ? parseFloat(created.salary) : null,
  });
});

// GET /employees/:id
router.get("/employees/:id", async (req, res) => {
  const parsed = GetEmployeeParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid ID" });
  }

  const [employee] = await db
    .select()
    .from(employeesTable)
    .where(eq(employeesTable.id, parsed.data.id));

  if (!employee) {
    return res.status(404).json({ error: "Employee not found" });
  }

  return res.json({
    ...employee,
    salary: employee.salary ? parseFloat(employee.salary) : null,
  });
});

// PATCH /employees/:id
router.patch("/employees/:id", async (req, res) => {
  const paramsParsed = UpdateEmployeeParams.safeParse({ id: Number(req.params.id) });
  if (!paramsParsed.success) {
    return res.status(400).json({ error: "Invalid ID" });
  }

  const bodyParsed = UpdateEmployeeBody.safeParse(req.body);
  if (!bodyParsed.success) {
    return res.status(400).json({ error: bodyParsed.error.message });
  }

  const { salary, hireDate, ...rest } = bodyParsed.data;
  const updates: Record<string, unknown> = { ...rest, updatedAt: new Date() };
  if (salary !== undefined) {
    updates.salary = String(salary);
  }
  if (hireDate !== undefined) {
    updates.hireDate = hireDate instanceof Date ? hireDate.toISOString().slice(0, 10) : String(hireDate);
  }

  const [updated] = await db
    .update(employeesTable)
    .set(updates)
    .where(eq(employeesTable.id, paramsParsed.data.id))
    .returning();

  if (!updated) {
    return res.status(404).json({ error: "Employee not found" });
  }

  return res.json({
    ...updated,
    salary: updated.salary ? parseFloat(updated.salary) : null,
  });
});

// DELETE /employees/:id
router.delete("/employees/:id", async (req, res) => {
  const parsed = DeleteEmployeeParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid ID" });
  }

  const [deleted] = await db
    .delete(employeesTable)
    .where(eq(employeesTable.id, parsed.data.id))
    .returning();

  if (!deleted) {
    return res.status(404).json({ error: "Employee not found" });
  }

  return res.json({ success: true });
});

export default router;
